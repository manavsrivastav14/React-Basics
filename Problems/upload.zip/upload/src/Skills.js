import { Component } from "react";

export default class Skills extends Component {
  render() {
    return (
      <div className="Skills">
        <div className="skill-name">HTML</div>
        <div className="skill-name">CSS</div>
        <div className="skill-name">JS</div>
        <div className="skill-name">Mendix</div>
        <div className="skill-name">React</div>
        <div className="skill-name">Node Js</div>
      </div>
    );
  }
}
