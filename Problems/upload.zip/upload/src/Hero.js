import { Component } from "react";

export default class Hero extends Component {
  render() {
    return (
      <div className="Hero">
        <h3>Name: Manav Harsh Srivastava</h3>
        <p>Email: manav@gmail.com</p>
        <p>Phone: 9999999999</p>
        <p>Address: ABC, XYZ Street, Yemen</p>
      </div>
    );
  }
}
